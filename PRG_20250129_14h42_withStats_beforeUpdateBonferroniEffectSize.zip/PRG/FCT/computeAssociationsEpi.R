computeAssociationsEpi <- function(data, varList, outCSV = NULL) {
  # data   : data.frame contenant les variables catégorielles
  # varList: vecteur de noms de variables à tester deux à deux
  # outCSV : chemin (ou NULL) pour exporter le tableau de résultats en CSV
  
  # Créer un data.frame pour accumuler les résultats
  results <- data.frame(
    var1     = character(),
    var2     = character(),
    testUsed = character(),
    pValue   = numeric(),
    cramerV  = numeric(),
    stringsAsFactors = FALSE
  )
  
  for (i in seq_len(length(varList) - 1)) {
    for (j in seq(i + 1, length(varList))) {
      
      v1 <- varList[i]
      v2 <- varList[j]
      
      # Construire la table de contingence
      tab <- table(data[[v1]], data[[v2]])
      n   <- sum(tab)
      
      # Déterminer s'il s'agit d'une table 2x2
      is2x2 <- (nrow(tab) == 2 && ncol(tab) == 2)
      
      # Préparer des variables pour stocker les résultats
      p_val   <- NA_real_
      c_v     <- NA_real_
      test_ok <- NA_character_
      
      # Test du Chi-2 standard (et on regarde les effectifs attendus)
      suppressWarnings({
        chi2_res  <- chisq.test(tab, correct = FALSE)  # Yates correction = FALSE par ex.
      })
      expected  <- chi2_res$expected
      # Comptons combien de cellules avec effectifs attendus < 5
      low_cells <- sum(expected < 5)
      perc_low  <- 100 * (low_cells / length(expected))
      
      # 1) Cas 2x2 : on préfère Fisher (sauf si table énorme → simulation)
      if (is2x2) {
        # On fait un test de Fisher standard (2x2)
        # Si jamais message mémoire → on peut passer à simulate=TRUE
        fisher_res <- fisher.test(tab)
        p_val      <- fisher_res$p.value
        test_ok    <- "Fisher_2x2"
        # Cramér’s V sur 2x2 => identique à phi => on peut le calculer si tu veux
        #c_v = sqrt(chi2_res$statistic / n) #to comment if we prefer NA
        #    (Ici, on peut simplement laisser NA ou calculer manuellement)
        
      } else {
        # 2) Table > 2x2
        # On regarde si +20% des expected < 5 => basculer sur Fisher simulate
        # Cela signifie que, pour chaque paire de variables, plus de 20% des effectifs attendus dans la table de contingence étaient < 5. Dans le code actuel, cela déclenche un test exact de Fisher (avec simulation Monte-Carlo) au lieu du Chi-2
        # En clair, si perc_low > 20, les tables ont suffisamment de combinaisons « rares » pour que le Chi-2 soit considéré « non fiable » selon la règle “> 20% de cellules < 5”.
        # Autre stratégie plus “épidémio” :
        # Si tu as beaucoup de catégories (ex. Device = 9 niveaux, Position = 4 niveaux), tu peux regrouper certaines modalités pour réduire la taille du tableau et augmenter les fréquences par cellule. Ainsi, le test du Chi-2 devient plus approprié.
        if (perc_low > 20) {
          # => Fisher simulate
          fisher_res <- fisher.test(tab, simulate.p.value = TRUE, B = 10000)
          p_val      <- fisher_res$p.value
          test_ok    <- "FisherSim"
          
        } else {
          # => Chi-2 standard
          p_val   <- chi2_res$p.value
          test_ok <- "Chi2"
          # Calcul Cramér’s V
          chi2_stat <- as.numeric(chi2_res$statistic)
          k         <- min(nrow(tab), ncol(tab))
          c_v       <- sqrt((chi2_stat / n) / (k - 1))
        }
      }
      
      # Sauvegarder la ligne
      results <- rbind(
        results,
        data.frame(
          var1     = v1,
          var2     = v2,
          testUsed = test_ok,
          pValue   = p_val,
          cramerV  = c_v,
          stringsAsFactors = FALSE
        )
      )
    }
  }
  
  # Export CSV si demandé
  if (!is.null(outCSV)) {
    write.csv2(results, file = outCSV, row.names = FALSE)
  }
  
  return(results)
}
