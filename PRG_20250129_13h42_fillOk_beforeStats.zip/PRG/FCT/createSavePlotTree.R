createSavePlotTree <- function (data, variable_order, savePlot, pathSavePlot, plotTitle){
  
  # Pour la v2 = 1 seule feuille contenant toutes les études (du dernier embranchement)
  only1leave = FALSE #FALSE #TRUE #HUMAN CHOICE
  if (only1leave){
    #Create interaction so that 1 level of "interaction" will be 1 leaf (and could contain 1 or multiple studies) 
    data$interact <- interaction(data$Position, data$Device, data$EpochDuration, data$DropTime, data$BoutDuration, sep="+")
    #Get a number per study
    data <- data %>%  mutate(StudyIDNb = row_number())
    
    #Export and print this number (for human reading)
    indexArticles <- interaction(data$StudyIDNb, data$StudyID, sep=" : ")
    indexArticles <- gsub("_", " ", indexArticles)
    indexArticles <- gsub("@", ",", indexArticles)
    cat(paste("\n\n Correspondance between indexes and articles:\n\n", paste(indexArticles, collapse = "\n"), "\n\n", sep=""))
    
    # Création du nouveau dataframe en conservant les autres colonnes
    data <- data %>%
      group_by(interact) %>%  # Regroupement par les niveaux de interact
      summarise(
        StudyID = paste(StudyID, collapse = "+"),  # Concaténation de StudyID 
        StudyIDNb = paste(StudyIDNb, collapse = ", "), # Concaténation de StudyIDNb
        across(-c(StudyID, StudyIDNb), first)  # Conserver les autres colonnes
      ) %>%
      ungroup()  # Retirer le regroupement
    data$interact <- NULL
    
    # Compter le nombre d'article pour chaque leaf
    nb_articles <- nchar(gsub("[^+]", "", data$StudyID))+1
    
    # Add this number to the leaf
    #data$StudyID <- paste(nb_articles, " article(s) (", data$StudyID, ")" ,sep="") #possibility 1 (but too long)
    #data$StudyID <- paste(nb_articles, " article(s)", sep="") #possibility 2 (but no detailed info)
    data$StudyID <- paste(nb_articles, " article(s) (", data$StudyIDNb, ")" ,sep="") #possibility 1 (but too long)
    data$StudyIDNb <- NULL
    
    #We need to change before construction tree (because prbl with newick)
    data$StudyID <- gsub(" ", "_", data$StudyID)
    data$StudyID <- gsub(",", "@", data$StudyID)
    data$StudyID <- gsub("\\(", "parOpen", data$StudyID)
    data$StudyID <- gsub("\\)", "parClose", data$StudyID)
  }
  
  # Génère un arbre fictif
  #tree <- create_tree(data) # Appeler la fonction avec l'ordre par défaut
  tree <- create_tree(data, variable_order) # Appeler la fonction avec un ordre personnalisé
  tree$tip.label <- gsub("_", " ", tree$tip.label) #to re-change after constructing tree
  tree$tip.label <- gsub("@", ",", tree$tip.label) #to re-change after constructing tree
  tree$tip.label <- gsub("parOpen", "\\(", tree$tip.label)
  tree$tip.label <- gsub("parClose", "\\)", tree$tip.label)
  
  # Générer les annotations pour les noms des variables
  variable_labels <- add_variable_labels(tree, variable_order)
  
  # Créer un plot
  p <- getPlotTree(tree, variable_labels, plotTitle, only1leave)
  
  # Print plot
  print(p)
  
  # Save plot
  if (savePlot){
    adjustDynamically = T
    
    if(adjustDynamically){
      #tip height  # on ajuste le « 4 » selon le rendu souhaité
      tipH <- 6 #6 is nice if color fill #4.8 #4.8 is nice if not fill #4.2 is old
      
      # On calcule la hauteur en se basant sur le nombre de tips
      nTips        <- length(tree$tip.label)
      #dynamicWidth <- 800 #1000                    # ou un autre chiffre de base
      dynamicWidth <- 350 #300 #nouvelle version condensée
      dynamicHeight <- tipH * nTips         
      
      #save
      ggsave(
        filename = pathSavePlot, 
        plot     = p, 
        dpi      = 300,
        units    = "mm",         # en mm
        width    = dynamicWidth,
        height   = dynamicHeight,
        limitsize = FALSE
      )
      
    } else {
      #ggsave(filename = file.path(RES_PATH, "Arbre_Descriptif_Publication.png"), plot = p, width = 12, height = 8, dpi = 300)
      ggsave(filename = pathSavePlot, plot = p, dpi = 300)
    }
  }
}