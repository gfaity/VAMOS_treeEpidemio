createSaveSankeyAllVars <- function(
    data,
    variable_order,
    pathSavePlot = NULL,
    plotTitle = "Sankey Diagram",
    doSavePlot = TRUE
){
  # 1) Exclure StudyID de variable_order
  varList <- setdiff(variable_order, c("StudyID"))
  
  # Vérifier qu'on n'a pas trop de variables (ggalluvial : max 9 axes)
  if (length(varList) > 9) {
    stop("ggalluvial gère jusqu'à 9 axes (axis1..axis9). Veuillez réduire le nombre de variables.")
  }
  # Vérifier qu'on en a au moins 2 (sinon pas de flux)
  if (length(varList) < 2) {
    stop("Besoin d'au moins 2 variables pour un Sankey.")
  }
  
  # 2) Construire un tableau de contingence global : combien d'articles par combinaison des variables
  dfSankey <- data %>%
    group_by(across(all_of(varList))) %>%
    summarise(Freq = n(), .groups = "drop")
  
  # 3) Construire dynamiquement le mapping aes(axis1=..., axis2=..., etc.)
  #    pour ggalluvial
  #    axis1 => varList[1], axis2 => varList[2], etc.
  axisMapping <- setNames(
    lapply(varList, rlang::sym),    # pour aes(axis1= sym(varList[1]), ...)
    paste0("axis", seq_along(varList))
  )
  
  # Créer l’aes pour y = Freq, plus nos axes dynamiques
  # Note : on colorie/fill par la 1ère variable (à adapter si souhaité)
  aesthetic <- do.call(aes, c(list(y = rlang::sym("Freq"),
                                   fill = rlang::sym(varList[1])),
                              axisMapping))
  
  # 4) Construire le ggplot
  p <- ggplot(dfSankey, aesthetic) +
    geom_alluvium(width = 1/12) + 
    geom_stratum(width = 1/12, fill = "grey90", color = "black") +
    geom_text(stat = "stratum", aes(label = after_stat(stratum)), size = 3) +
    # On définit l'ordre des axes horizontaux = noms des variables
    scale_x_discrete(limits = varList) +
    labs(title = plotTitle, y = "Number of Articles") +
    theme_minimal(base_size = 12) +
    theme(legend.position = "bottom")
  
  # 5) Sauvegarder si demandé
  if (doSavePlot && !is.null(pathSavePlot)) {
    ggsave(filename = pathSavePlot, plot = p, width = 8, height = 5, dpi = 300, bg = "white")
  }
  
  return(p)
}

