# Cette fonction :
#   Agrège les données par les variables choisies (par défaut : EpochDuration, DropTime, BoutDuration).
#   Calcule le nombre d’articles par combinaison de niveaux.
#   Produit un Sankey diagram via ggalluvial.
#   Sauvegarde éventuellement le graphique en PNG (ou n’importe quel autre format géré par ggsave).
#
# Comment ça marche ?
#   varList : un vecteur de 3 variables catégorielles, dans l’ordre où tu veux les “axes” du Sankey (axis1, axis2, axis3).
#   dfSankey : calcule Freq = n() articles par combinaison (var1, var2, var3).
#   geom_alluvium() : dessine les flux reliant les strates (geom_stratum()).
#   fill = .data[[varList[1]]] : les couleurs sont associées au premier facteur (ex. EpochDuration), mais tu peux choisir un autre mapping si tu préfères.

createSaveSankey_3var <- function(
    data,
    varList = c("EpochDuration", "DropTime", "BoutDuration"),
    pathSavePlot = NULL,  # chemin pour sauvegarder (ex: "Sankey_Epoch-Drop-Bout.png")
    plotTitle    = "Sankey Diagram of Studies",
    doSavePlot   = TRUE
) {
  # 1) Vérifier que les variables existent
  if (!all(varList %in% names(data))) {
    stop("Certaines variables de varList ne sont pas présentes dans le dataframe.")
  }
  if (length(varList) != 3) {
    stop("Cette fonction d'exemple est conçue pour EXACTEMENT 3 variables (ex. Epoch->Drop->Bout).")
  }
  
  # 2) Agréger: calculer le nombre d'articles (Freq) pour chaque combinaison
  dfSankey <- data %>%
    group_by(across(all_of(varList))) %>%
    summarise(Freq = n(), .groups = "drop")
  
  # 3) Construire le Sankey avec ggalluvial
  #    On suppose varList = c("EpochDuration", "DropTime", "BoutDuration")
  p <- ggplot(dfSankey,
              aes(axis1 = .data[[varList[1]]],
                  axis2 = .data[[varList[2]]],
                  axis3 = .data[[varList[3]]],
                  y = Freq)) +
    geom_alluvium(aes(fill = .data[[varList[1]]]), width = 1/12) +
    geom_stratum(width = 1/12, fill = "grey90", color = "black") +
    geom_text(stat = "stratum", aes(label = after_stat(stratum)), size = 3) +
    scale_x_discrete(limits = varList) +
    theme_minimal() +
    labs(title = plotTitle, y = "Number of Articles") +
    theme(legend.position = "bottom")
  
  # 4) Optionnel: sauvegarder le plot si demandé
  if (doSavePlot && !is.null(pathSavePlot)) {
    ggsave(filename = pathSavePlot, plot = p, width = 8, height = 5, dpi = 300)
  }
  
  return(p)
}
